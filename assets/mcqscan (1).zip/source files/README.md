# Bubble Sheet Multiple Choice Scanner


## Steps

* Dilate source image for better recognition
* Transform to Grayscale format
* Threshold operation (for recognizing mask/conjuction with bitwise_and)
* Blur filter
* Canny edge algorithm
* Adaptive Thresh (for find main wrapper rectangle & bubbles)
* Recognize main wrapper rectangle according to hierarchy
* Find bubbles with estimated ratio (~17/15.5)
* Sort bubbles by coordinate points
* Recognize which option is filled or empty with bitwise_and and countNonZero

## Sources

* Pdf - [Bubble Sheet Form](sources/bubble-sheet.pdf)
* Inputs - Example Sheet [1](sources/sheet-1.jpg) & [2](sources/sheet-2.jpg)
* Outputs for Sheet [1](sources/result-sheet-1.png) & [2](sources/result-sheet-2.png)

## Running

Run the "main" method of Main class.

```
    public static void main(String[] args) throws Exception {

        sout("...started");

    (1) Mat source = Imgcodecs.imread(getSource("sheet-1.jpg"));

        Scanner scanner = new Scanner(source, 20);
    (2) scanner.setLogging(true);
        scanner.scan();

        sout("...finished");
    }
```

(1) change source file name

(2) if logging is 

* enabled, you can see processing flow and some detailed logs.

* disabled, you can see only output/result file.

## Output (for sheet-2)

```
...started
*************************************
*************************************
answer is ....
*************************************
*************************************
1. A
2. D
3. B
4. EMPTY/INVALID
5. D
6. A
7. D
8. C
9. A
10. EMPTY/INVALID
11. B
12. A
13. D
14. EMPTY/INVALID
15. B
16. EMPTY/INVALID
17. EMPTY/INVALID
18. C
19. EMPTY/INVALID
20. D
...finished
```

![alt text](sources/result-sheet-2.png "Output of Sheet Two")
